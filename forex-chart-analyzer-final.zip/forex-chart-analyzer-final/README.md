# Forex Chart Analyzer — Final

This is a mobile-friendly, installable web app with a secure server-side OpenAI API call.

## What is included
- Upload up to 3 screenshots (H1/M15/M5)
- Multi-timeframe analysis
- BUY / SELL / WAIT
- Market structure
- Support/resistance
- Entry, SL, TP1, TP2
- Confirmation requirements
- Confidence and risk notes
- Mobile/PWA layout
- Render deployment configuration

## Easiest way to put it online

### Option A — Render (recommended)
1. Create a GitHub account.
2. Create a new repository.
3. Upload all files from this folder to the repository.
4. Create a Render account.
5. Create a new Web Service from the GitHub repository.
6. Render will use `render.yaml`.
7. In Render, add the environment variable `OPENAI_API_KEY` with your API key.
8. Deploy.
9. Open the Render URL on your Android phone.
10. Use your browser menu and choose "Add to Home screen" / "Install app" if offered.

### Option B — run on your computer
1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add your OpenAI API key.
6. Run `npm start`.
7. Open http://localhost:3000.

## Important
Never put the API key in public/index.html. The key belongs in the server environment.

The app does not place trades or connect to a broker. It analyzes screenshots and produces an educational setup.

## Cost
The AI calls use the OpenAI API and are billed according to the selected model and usage. Check current OpenAI pricing before launching publicly.
