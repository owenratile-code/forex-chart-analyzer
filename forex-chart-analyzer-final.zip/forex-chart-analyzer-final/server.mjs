import "dotenv/config";
import express from "express";
import multer from "multer";
import OpenAI from "openai";

const app = express();
const port = Number(process.env.PORT || 3000);

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. Create a .env file before using Analyze.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 3 },
  fileFilter: (_req, file, cb) => {
    if (["image/png", "image/jpeg", "image/webp"].includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only PNG, JPEG, and WEBP chart images are supported."));
    }
  }
});

const ANALYSIS_INSTRUCTIONS = `
You are a cautious forex/CFD technical-analysis assistant analyzing a chart screenshot.

Your job is to inspect ONLY what is reasonably visible in the supplied chart and produce a structured analysis.
Do not pretend that you can see data that is cropped, blurry, hidden, or not present.

Analyze:
- instrument and timeframe shown on the chart
- current market structure: HH, HL, LH, LL where reasonably identifiable
- overall directional bias
- important support and resistance
- recent swing high/low
- liquidity areas if visually defensible
- fair value gaps only when visually defensible
- break of structure / change of character only when visually defensible
- a possible BUY setup and a possible SELL setup
- multi-timeframe alignment when multiple screenshots are supplied
- entry zone, invalidation/stop-loss zone, TP1 and TP2
- risk/reward estimate when the prices are readable
- confirmation that should occur before entry

Rules:
1. Never force a trade. If neither side has a clean setup, set action to WAIT.
2. Never invent exact prices. If a level cannot be read reliably, use null and explain why.
3. Distinguish "visible fact" from "interpretation".
4. This is educational market analysis, not a guarantee or financial advice.
5. Prefer a clear invalidation level over an arbitrary stop.
6. If the screenshot contains a price scale, use it carefully.
7. If the chart is missing enough context, lower confidence and say what is missing.
8. Do not claim a setup is high probability merely because it looks attractive.

Return ONLY valid JSON with exactly these top-level keys:
{
  "instrument": string|null,
  "timeframe": string|null,
  "multi_timeframe_summary": string,
  "bias": "BULLISH"|"BEARISH"|"NEUTRAL",
  "action": "BUY"|"SELL"|"WAIT",
  "confidence": number,
  "market_structure": string,
  "support": [{"price": string, "reason": string}],
  "resistance": [{"price": string, "reason": string}],
  "buy_setup": {
    "entry": string|null,
    "stop_loss": string|null,
    "take_profit_1": string|null,
    "take_profit_2": string|null,
    "confirmation": string,
    "reason": string
  },
  "sell_setup": {
    "entry": string|null,
    "stop_loss": string|null,
    "take_profit_1": string|null,
    "take_profit_2": string|null,
    "confirmation": string,
    "reason": string
  },
  "key_observations": [string],
  "risk_notes": [string]
}

Confidence must be an integer from 0 to 100. Use 0 when the image cannot be analyzed reliably.
`;

app.use(express.static("public"));

app.post("/api/analyze", upload.array("charts", 3), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is missing. Add it to your .env file." });
    }
    if (!req.files?.length) {
      return res.status(400).json({ error: "Please upload at least one chart image." });
    }

    const instrument = String(req.body.instrument || "Unknown");
    const timeframes = String(req.body.timeframes || "Unknown");

    const content = [{
      type: "input_text",
      text: `User-provided metadata: instrument=${instrument}; requested timeframes=${timeframes}.
Analyze ALL attached chart screenshots together. Prefer timeframe/instrument labels visible on the charts over user metadata.
Use the higher timeframe to establish direction, the middle timeframe to locate structure/setup, and the lower timeframe to define confirmation/execution when those charts are supplied.`
    }];

    for (const file of req.files) {
      const base64 = file.buffer.toString("base64");
      content.push({
        type: "input_image",
        image_url: `data:${file.mimetype};base64,${base64}`,
        detail: "high"
      });
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: ANALYSIS_INSTRUCTIONS,
      input: [{ role: "user", content }]
    });

    const raw = response.output_text?.trim() || "";
    let analysis;
    try {
      analysis = JSON.parse(raw);
    } catch {
      return res.status(502).json({
        error: "The model returned an unexpected format.",
        raw
      });
    }

    res.json({ analysis });
  } catch (err) {
    console.error(err);
    const message = err?.message || "Analysis failed.";
    res.status(500).json({ error: message });
  }
});

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Upload error." });
});

app.listen(port, () => {
  console.log(`Forex Chart Analyzer running at http://localhost:${port}`);
});
